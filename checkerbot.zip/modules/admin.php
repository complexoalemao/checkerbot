<?php
/*
=========================
 ADMIN COMMANDS
=========================
*/

require_once __DIR__ . "/../config/config.php";
require_once __DIR__ . "/../config/variables.php";
require_once __DIR__ . "/../functions/bot.php";
require_once __DIR__ . "/../functions/db.php";
require_once __DIR__ . "/../functions/functions.php";

/*
=========================
 SECURITY CHECK
=========================
*/
if (!isset($userId, $message, $chat_id, $message_id)) {
    return;
}

if ($userId != $config['adminID']) {
    return;
}

/*
=========================
 /MUTE
 Format: /mute userID|10m OR /mute userID|10d
=========================
*/
if (strpos($message, "/mute ") === 0) {

    $data = explode("|", trim(substr($message, 6)));

    if (count($data) !== 2) {
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "<b>Invalid format.</b>\nUse: <code>/mute userID|10m</code>",
            'parse_mode' => 'html',
            'reply_to_message_id' => $message_id
        ]);
        return;
    }

    [$targetId, $time] = $data;

    if (stripos($time, 'm') !== false) {
        $muteUntil = add_minutes(time(), $time);
    } elseif (stripos($time, 'd') !== false) {
        $muteUntil = add_days(time(), $time);
    } else {
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "<b>Invalid time format.</b>",
            'parse_mode' => 'html',
            'reply_to_message_id' => $message_id
        ]);
        return;
    }

    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => muteUser($targetId, $muteUntil),
        'parse_mode' => 'html',
        'reply_to_message_id' => $message_id
    ]);
}

/*
=========================
 /UNMUTE
=========================
*/
if (strpos($message, "/unmute ") === 0) {

    $targetId = trim(substr($message, 8));

    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => unmuteUser($targetId),
        'parse_mode' => 'html',
        'reply_to_message_id' => $message_id
    ]);
}

/*
=========================
 /BAN
=========================
*/
if (strpos($message, "/ban ") === 0) {

    $targetId = trim(substr($message, 5));

    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => banUser($targetId),
        'parse_mode' => 'html',
        'reply_to_message_id' => $message_id
    ]);
}

/*
=========================
 /UNBAN
=========================
*/
if (strpos($message, "/unban ") === 0) {

    $targetId = trim(substr($message, 7));

    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => unbanUser($targetId),
        'parse_mode' => 'html',
        'reply_to_message_id' => $message_id
    ]);
}

/*
=========================
 /ADMIN HELP
=========================
*/
if ($message === "/admin") {

    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => "<b>Admin Commands</b>

<code>/mute userID|10m</code>
<code>/mute userID|10d</code>

<code>/unmute userID</code>
<code>/ban userID</code>
<code>/unban userID</code>

<code>/mutelist</code>
<code>/banlist</code>

<code>/botstats</code>
<code>/userstats userID</code>",
        'parse_mode' => 'html',
        'reply_to_message_id' => $message_id
    ]);
}

/*
=========================
 /BANLIST
=========================
*/
if ($message === "/banlist") {

    $list = fetchBanlist();

    if (empty($list)) {
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "<b>No banned users.</b>",
            'parse_mode' => 'html',
            'reply_to_message_id' => $message_id
        ]);
        return;
    }

    $file = tempnam(sys_get_temp_dir(), 'ban_');
    file_put_contents($file, implode("\n", $list));

    sendDocument($chat_id, $file, "Total Banned: " . count($list), $message_id);
    unlink($file);
}

/*
=========================
 /MUTELIST
=========================
*/
if ($message === "/mutelist") {

    $list = fetchMutelist();

    if (empty($list)) {
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "<b>No muted users.</b>",
            'parse_mode' => 'html',
            'reply_to_message_id' => $message_id
        ]);
        return;
    }

    $rows = [];
    foreach ($list as $uid) {
        $timer = fetchMuteTimer($uid);
        $rows[] = $uid . " | Until: " . date("d/m/Y H:i", $timer['mute_timer']);
    }

    $file = tempnam(sys_get_temp_dir(), 'mute_');
    file_put_contents($file, implode("\n", $rows));

    sendDocument($chat_id, $file, "Total Muted: " . count($rows), $message_id);
    unlink($file);
}

/*
=========================
 /USERSTATS
=========================
*/
if (strpos($message, "/userstats ") === 0) {

    $targetId = trim(substr($message, 11));
    $stats = fetchUserStats($targetId);

    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => "≡ <b>User Stats</b>

ID: <code>$targetId</code>

- Checked: {$stats['total_checked']}
- CVV: {$stats['total_cvv']}
- CCN: {$stats['total_ccn']}",
        'parse_mode' => 'html',
        'reply_to_message_id' => $message_id
    ]);
}

/*
=========================
 /BOTSTATS
=========================
*/
if ($message === "/botstats") {

    $totalUsers = totalUsers();
    $gStats = fetchGlobalStats();

    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => "≡ <b>Bot Stats</b>

- Members: $totalUsers
- Banned: " . totalBanned() . "
- Muted: " . totalMuted() . "

≡ <b>Global Checker</b>

- Checked: {$gStats['total_checked']}
- CVV: {$gStats['total_cvv']}
- CCN: {$gStats['total_ccn']}",
        'parse_mode' => 'html',
        'reply_to_message_id' => $message_id
    ]);
}
