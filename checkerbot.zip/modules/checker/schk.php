<?php
/*
========================================
 Stripe User Merchant Commands
 /schk creditcard - Checks the Credit Card
========================================
*/

/* ===== BASE PATH CORRETO ===== */
$base = dirname(__DIR__, 2);

/* ===== INCLUDES CORRIGIDOS ===== */
require_once $base . '/config/config.php';
require_once $base . '/config/variables.php';
require_once $base . '/functions/bot.php';
require_once $base . '/functions/db.php';
require_once $base . '/functions/functions.php';


/* ===== COMMAND ===== */
if (strpos($message, "/schk ") === 0 || strpos($message, "!schk ") === 0) {

    $antispam = antispamCheck($userId);
    addUser($userId);

    if ($antispam !== false) {
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "[<u>ANTI SPAM</u>] Try again after <b>$antispam</b>s.",
            'parse_mode' => 'html',
            'reply_to_message_id' => $message_id
        ]);
        return;
    }

    /* ===== WAIT MESSAGE ===== */
    $msg = bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => "<b>Wait for Result...</b>",
        'parse_mode' => 'html',
        'reply_to_message_id' => $message_id
    ]);

    $messageidtoedit = $msg->result->message_id ?? null;

    $lista = substr($message, 6);

    /* ===== CC REGEX ===== */
    if (!preg_match(
        "/(\d{16})[\/\s:|]*(\d{2})[\/\s|]*(\d{2,4})[\/\s|-]*(\d{3})/",
        $lista,
        $matches
    )) {
        bot('editMessageText', [
            'chat_id' => $chat_id,
            'message_id' => $messageidtoedit,
            'text' => "<b>Provide a valid CC to check.</b>",
            'parse_mode' => 'html'
        ]);
        return;
    }

    /* ===== CC DATA ===== */
    $cc   = $matches[1];
    $mon  = $matches[2];
    $year = $matches[3];
    $cvv  = $matches[4];
    $bin  = substr($cc, 0, 6);

    $sec = fetchAPIKey($userId);

    if (!preg_match("/sk_(test|live)_/i", $sec)) {
        bot('editMessageText', [
            'chat_id' => $chat_id,
            'message_id' => $messageidtoedit,
            'text' => "<b>Add a SK Key first using /apikey sk_live</b>",
            'parse_mode' => 'html'
        ]);
        return;
    }

    /* ===== BIN LOOKUP ===== */
    $ch = curl_init("https://lookup.binlist.net/$bin");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERAGENT => "Mozilla/5.0"
    ]);
    $binData = curl_exec($ch);
    curl_close($ch);

    $bank     = capture($binData, '"bank":{"name":"', '"') ?: "Unavailable";
    $scheme   = ucfirst(capture($binData, '"scheme":"', '"') ?: "Unavailable");
    $type     = ucfirst(capture($binData, '"type":"', '"') ?: "Unavailable");
    $country  = capture($binData, '"country":{"name":"', '"') ?: "Unavailable";
    $emoji    = capture($binData, '"emoji":"', '"') ?: "";
    $currency = capture($binData, '"currency":"', '"') ?: "Unavailable";
    $phone    = capture($binData, '"phone":"', '"') ?: "Unavailable";

    /* ===== STRIPE SOURCE ===== */
    $ch = curl_init("https://api.stripe.com/v1/sources");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERPWD => $sec . ":",
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS =>
            "type=card&card[number]=$cc&card[exp_month]=$mon&card[exp_year]=$year&card[cvc]=$cvv",
    ]);
    $result = curl_exec($ch);
    curl_close($ch);

    if (strpos($result, '"error"') !== false) {
        $err = capture($result, '"message":"', '"');
        bot('editMessageText', [
            'chat_id' => $chat_id,
            'message_id' => $messageidtoedit,
            'text' => "<b>Status:</b> Dead ❌\n<code>$err</code>",
            'parse_mode' => 'html'
        ]);
        return;
    }

    $sourceId = capture($result, '"id":"', '"');

    /* ===== STRIPE CUSTOMER ===== */
    $start = microtime(true);

    $ch = curl_init("https://api.stripe.com/v1/customers");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERPWD => $sec . ":",
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => "source=$sourceId"
    ]);
    $result2 = curl_exec($ch);
    curl_close($ch);

    $time = round(microtime(true) - $start, 2);

    $live = array_in_string($result2, $live_array);
    $response = $live
        ? capture($result2, '"message":"', '"')
        : capture($result2, '"decline_code":"', '"');

    /* ===== STATS ===== */
    addTotal();
    addUserTotal($userId);

    if ($live) {
        addCCN();
        addUserCCN($userId);
        addCVV();
        addUserCVV($userId);
    }

    /* ===== FINAL MESSAGE ===== */
    bot('editMessageText', [
        'chat_id' => $chat_id,
        'message_id' => $messageidtoedit,
        'parse_mode' => 'html',
        'disable_web_page_preview' => true,
        'text' => "
<b>Card:</b> <code>$cc|$mon|$year|$cvv</code>
<b>Status:</b> " . ($live ? "Approved ✅" : "Dead ❌") . "
<b>Response:</b> <code>$response</code>
<b>Time:</b> {$time}s

<b>Bank:</b> $bank
<b>Brand:</b> $scheme
<b>Type:</b> $type
<b>Country:</b> $country $emoji
<b>Currency:</b> $currency
<b>Phone:</b> $phone

<b>Checked By:</b> <a href='tg://user?id=$userId'>$firstname</a>
"
    ]);
}
