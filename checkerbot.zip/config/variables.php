<?php

// Recebe o update do Telegram
$update = json_decode(file_get_contents("php://input"));

// Variáveis do message
$chat_id = $update->message->chat->id ?? null;
$userId = $update->message->from->id ?? null;
$firstname = $update->message->from->first_name ?? null;
$lastname = $update->message->from->last_name ?? null;
$username = $update->message->from->username ?? null;
$chattype = $update->message->chat->type ?? null;
$message = $update->message->text ?? null;
$message_id = $update->message->message_id ?? null;
$replytomessageis = $update->message->reply_to_message->text ?? null;

// Variáveis do callback_query
$data = $update->callback_query->data ?? null;
$callbackfname = $update->callback_query->from->first_name ?? null;
$callbacklname = $update->callback_query->from->last_name ?? null;
$callbackusername = $update->callback_query->from->username ?? null;
$callbackchatid = $update->callback_query->message->chat->id ?? null;
$callbackuserid = $update->callback_query->message->reply_to_message->from->id ?? null;
$callbackmessageid = $update->callback_query->message->message_id ?? null;

// Array de checagem de erros ou mensagens de status
$live_array = array(
    'incorrect_cvc', 
    '"cvc_check": "fail"', 
    '"cvc_check": "pass"', 
    'insufficient_funds',
    'Your card does not support this type of purchase',
    'transaction_not_allowed',
    'CVV INVALID'
);

?>
