<?php
// =========================
// TELEGRAM BOT FUNCTIONS
// =========================

// Segurança: garante que o CURL existe
if (!extension_loaded('curl')) {
    die("❌ PHP extension CURL is not enabled. Enable extension=curl in php.ini");
}

/**
 * Core Telegram Bot Function
 */
function bot(string $method, array $datas = [])
{
    global $config;

    if (empty($config['botToken'])) {
        return false;
    }

    $url = "https://api.telegram.org/bot" . $config['botToken'] . "/" . $method;

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $datas,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $response = curl_exec($ch);

    if ($response === false) {
        error_log('CURL ERROR: ' . curl_error($ch));
        curl_close($ch);
        return false;
    }

    curl_close($ch);

    return json_decode($response, true);
}

// =========================
// SHORTCUT FUNCTIONS
// =========================

function sendMessage($chat_id, $text, $keyboard = null)
{
    $data = [
        'chat_id' => $chat_id,
        'text'    => $text,
        'parse_mode' => 'html'
    ];

    if ($keyboard !== null) {
        $data['reply_markup'] = $keyboard;
    }

    return bot('sendMessage', $data);
}

function editMessage($chat_id, $message_id, $text, $reply_markup = null)
{
    $data = [
        'chat_id'    => $chat_id,
        'message_id' => $message_id,
        'text'       => $text,
        'parse_mode' => 'html'
    ];

    if ($reply_markup !== null) {
        $data['reply_markup'] = $reply_markup;
    }

    return bot('editMessageText', $data);
}

function forwardMessage($chat_id, $from_chat_id, $message_id)
{
    return bot('forwardMessage', [
        'chat_id'      => $chat_id,
        'from_chat_id' => $from_chat_id,
        'message_id'   => $message_id
    ]);
}

function copyMessage($chat_id, $from_chat_id, $message_id)
{
    return bot('copyMessage', [
        'chat_id'      => $chat_id,
        'from_chat_id' => $from_chat_id,
        'message_id'   => $message_id
    ]);
}

function sendPhoto($chat_id, $photo, $keyboard = null)
{
    $data = [
        'chat_id' => $chat_id,
        'photo'   => $photo
    ];

    if ($keyboard !== null) {
        $data['reply_markup'] = $keyboard;
    }

    return bot('sendPhoto', $data);
}
