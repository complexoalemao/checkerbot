<?php

// =========================
// SAFE INCLUDES
// =========================
require_once __DIR__ . "/../config/config.php";
require_once __DIR__ . "/../functions/bot.php";

// =========================
// STRING CAPTURE
// =========================
function capture(string $string, string $start, string $end): string
{
    if ($string === '' || $start === '' || $end === '') {
        return '';
    }

    if (!str_contains($string, $start)) {
        return '';
    }

    $parts = explode($start, $string, 2);
    if (!isset($parts[1])) {
        return '';
    }

    $parts = explode($end, $parts[1], 2);
    return $parts[0] ?? '';
}

// =========================
// LOG SUMMARY
// =========================
function logsummary(string $summary): void
{
    global $config;

    if (empty($config['logsID']) || $summary === '') {
        return;
    }

    bot('sendMessage', [
        'chat_id' => $config['logsID'],
        'text' => $summary,
        'parse_mode' => 'html'
    ]);
}

// =========================
// ADD DAYS
// =========================
function add_days(int $timestamp, string $days): int
{
    $days = (int) str_replace('d', '', $days);
    return $timestamp + (60 * 60 * 24 * $days);
}

// =========================
// ADD MINUTES
// =========================
function add_minutes(int $timestamp, string $minutes): int
{
    $minutes = (int) str_replace('m', '', $minutes);
    return $timestamp + (60 * $minutes);
}

// =========================
// MULTI EXPLODE
// =========================
function multiexplode(array $delimiters, string $string): array
{
    if (empty($delimiters)) {
        return [$string];
    }

    $delimiter = $delimiters[0];
    $string = str_replace($delimiters, $delimiter, $string);
    return explode($delimiter, $string);
}

// =========================
// ARRAY IN STRING
// =========================
function array_in_string(?string $str, array $arr): bool
{
    if (empty($str) || empty($arr)) {
        return false;
    }

    foreach ($arr as $value) {
        if ($value !== '' && stripos($str, $value) !== false) {
            return true;
        }
    }

    return false;
}
