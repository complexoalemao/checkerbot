<?php

// =========================
// SAFE INCLUDES
// =========================
require_once __DIR__ . "/../config/config.php";
require_once __DIR__ . "/../config/variables.php";
require_once __DIR__ . "/bot.php";

// =========================
// DB CONFIG
// =========================
$DB_HOST = $config['db']['hostname'] ?? '127.0.0.1';
$DB_USER = $config['db']['username'] ?? 'root';
$DB_PASS = $config['db']['password'] ?? '';
$DB_NAME = $config['db']['database'] ?? '';
$DB_PORT = $config['db']['port'] ?? 3306;

// =========================
// CHECK MYSQLI EXTENSION
// =========================
if (!extension_loaded('mysqli')) {
    $error = "❌ PHP extension <b>mysqli</b> is not enabled.";

    if (function_exists('bot')) {
        bot('sendMessage', [
            'chat_id' => $config['adminID'],
            'text' => $error,
            'parse_mode' => 'html'
        ]);
    }

    die($error);
}

// Disable mysqli warnings (avoid crash)
mysqli_report(MYSQLI_REPORT_OFF);

// =========================
// CONNECT
// =========================
$conn = mysqli_connect(
    $DB_HOST,
    $DB_USER,
    $DB_PASS,
    $DB_NAME,
    $DB_PORT
);

if (!$conn) {
    $error = "<b>🛑 DB connection failed!</b>\n\n<code>" . mysqli_connect_error() . "</code>";

    bot('sendMessage', [
        'chat_id' => $config['adminID'],
        'text' => $error,
        'parse_mode' => 'html'
    ]);

    die($error);
}

mysqli_set_charset($conn, "utf8mb4");

// =========================
// USER FUNCTIONS
// =========================
function fetchUser(int|string $userID): array|false
{
    global $conn;

    $userID = mysqli_real_escape_string($conn, (string)$userID);
    $res = mysqli_query($conn, "SELECT * FROM users WHERE userid='$userID' LIMIT 1");

    return ($res && mysqli_num_rows($res) > 0)
        ? mysqli_fetch_assoc($res)
        : false;
}

function isBanned(int|string $userID): bool
{
    global $chat_id, $message_id;

    $user = fetchUser($userID);
    if (!$user) return false;

    if (($user['is_banned'] ?? 'False') === 'True') {
        bot('sendMessage', [
            'chat_id' => $chat_id,
            'text' => "<b>🛑 You are banned.</b>",
            'parse_mode' => 'html',
            'reply_to_message_id' => $message_id
        ]);
        return true;
    }

    return false;
}

function isMuted(int|string $userID): bool
{
    global $chat_id, $message_id, $conn;

    $user = fetchUser($userID);
    if (!$user) return false;

    if (($user['is_muted'] ?? 'False') === 'True') {
        $muteTimer = (int)($user['mute_timer'] ?? 0);

        if ($muteTimer > time()) {
            bot('sendMessage', [
                'chat_id' => $chat_id,
                'text' => "<b>🛑 You are muted!\n\nTry again after <code>" .
                    date("F j, Y, g:i a", $muteTimer) .
                    "</code></b>",
                'parse_mode' => 'html',
                'reply_to_message_id' => $message_id
            ]);
            return true;
        }

        mysqli_query($conn, "UPDATE users SET is_muted='False', mute_timer='0' WHERE userid='$userID'");
    }

    return false;
}

function addUser(int|string $userID): bool
{
    global $conn;

    if (fetchUser($userID)) return false;

    $userID = mysqli_real_escape_string($conn, (string)$userID);

    mysqli_query($conn, "
        INSERT INTO users
        (userid, registered_on, is_banned, is_muted, mute_timer, sk_key, total_checked, total_cvv, total_ccn)
        VALUES
        ('$userID', '" . time() . "', 'False', 'False', '0', '', '0', '0', '0')
    ");

    return true;
}

// =========================
// MODERATION
// =========================
function muteUser(int|string $userID, int $time): string
{
    global $conn;
    if (!fetchUser($userID)) return "User not found.";

    mysqli_query($conn, "UPDATE users SET is_muted='True', mute_timer='$time' WHERE userid='$userID'");
    return "Muted until " . date("F j, Y, g:i a", $time);
}

function unmuteUser(int|string $userID): string
{
    global $conn;
    if (!fetchUser($userID)) return "User not found.";

    mysqli_query($conn, "UPDATE users SET is_muted='False', mute_timer='0' WHERE userid='$userID'");
    return "User unmuted.";
}

function banUser(int|string $userID): string
{
    global $conn;
    if (!fetchUser($userID)) return "User not found.";

    mysqli_query($conn, "UPDATE users SET is_banned='True' WHERE userid='$userID'");
    return "User banned.";
}

function unbanUser(int|string $userID): string
{
    global $conn;
    if (!fetchUser($userID)) return "User not found.";

    mysqli_query($conn, "UPDATE users SET is_banned='False' WHERE userid='$userID'");
    return "User unbanned.";
}

// =========================
// STATS
// =========================
function fetchGlobalStats(): array
{
    global $conn;
    $res = mysqli_query($conn, "SELECT * FROM global_checker_stats LIMIT 1");
    return $res ? mysqli_fetch_assoc($res) : [];
}

function addTotal() { global $conn; mysqli_query($conn, "UPDATE global_checker_stats SET total_checked = total_checked + 1"); }
function addCVV()   { global $conn; mysqli_query($conn, "UPDATE global_checker_stats SET total_cvv = total_cvv + 1"); }
function addCCN()   { global $conn; mysqli_query($conn, "UPDATE global_checker_stats SET total_ccn = total_ccn + 1"); }

function fetchUserStats(int|string $userID): array
{
    global $conn;
    $res = mysqli_query($conn, "SELECT total_checked,total_cvv,total_ccn FROM users WHERE userid='$userID'");
    return $res ? mysqli_fetch_assoc($res) : [];
}

// =========================
// API KEY
// =========================
function fetchAPIKey(int|string $userID): string
{
    global $conn;
    $res = mysqli_query($conn, "SELECT sk_key FROM users WHERE userid='$userID'");
    $row = $res ? mysqli_fetch_assoc($res) : [];
    return (string)($row['sk_key'] ?? '');
}

function updateAPIKey(int|string $userID, string $apikey): void
{
    global $conn;
    mysqli_query($conn, "UPDATE users SET sk_key='$apikey' WHERE userid='$userID'");
}
